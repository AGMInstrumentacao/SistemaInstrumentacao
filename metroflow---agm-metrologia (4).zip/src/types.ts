export interface User {
  id: number;
  name: string;
  role: 'admin' | 'quality' | 'production' | 'metrology';
  sector: string;
}

export interface Instrument {
  id: number;
  code: string;
  type: string;
  description: string;
  range: string;
  manufacturer: string;
  category: string;
  last_calibration: string;
  periodicity_months: number;
  next_calibration: string;
  status: 'OK' | 'VENCIDO' | 'ALERTA';
  current_sector: string;
  current_responsible: string;
  notes?: string;
}

export interface Stats {
  total: number;
  expired: number;
  warning: number;
  inUse: number;
}
