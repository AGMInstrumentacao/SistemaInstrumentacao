import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Box, 
  History, 
  Settings, 
  LogOut, 
  Search, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  User as UserIcon,
  MapPin,
  Moon,
  Sun,
  ChevronRight,
  Filter,
  FileText,
  ArrowRightLeft,
  Printer,
  X,
  Users,
  Trash2,
  Package,
  CheckSquare,
  Square,
  Building2,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Instrument, Stats } from './types';

// --- Components ---

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden"
        >
          <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-lg">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
              <X size={20} className="text-slate-400" />
            </button>
          </div>
          <div className="p-6">
            {children}
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
      active 
        ? 'bg-blue-900 text-white shadow-lg shadow-blue-900/20' 
        : 'text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
    }`}
  >
    <Icon size={20} />
    <span className="font-medium">{label}</span>
  </button>
);

const StatCard = ({ label, value, icon: Icon, colorClass }: { label: string, value: number, icon: any, colorClass: string }) => (
  <div className="glass-card p-6 flex items-center justify-between">
    <div>
      <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">{label}</p>
      <h3 className="text-3xl font-bold">{value}</h3>
    </div>
    <div className={`p-3 rounded-2xl ${colorClass}`}>
      <Icon size={24} className="text-white" />
    </div>
  </div>
);

const ReportCard = ({ title, desc, icon: Icon, color, onClick }: { title: string, desc: string, icon: any, color: string, onClick: () => void }) => {
  const colorMap: any = {
    blue: 'bg-blue-100 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400 group-hover:bg-blue-900',
    indigo: 'bg-indigo-100 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400 group-hover:bg-indigo-900',
    red: 'bg-red-100 text-red-600 dark:bg-red-500/10 dark:text-red-400 group-hover:bg-red-900',
    amber: 'bg-amber-100 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400 group-hover:bg-amber-900'
  };

  return (
    <div 
      onClick={onClick}
      className="glass-card p-6 hover:border-slate-300 dark:hover:border-slate-700 transition-all cursor-pointer group"
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-all group-hover:text-white ${colorMap[color]}`}>
        <Icon size={24} />
      </div>
      <h3 className="font-bold text-lg mb-2">{title}</h3>
      <p className="text-sm text-slate-500 leading-relaxed">{desc}</p>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isPrintMode, setIsPrintMode] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Efeito para lidar com o modo de impressão manual
  useEffect(() => {
    if (isPrintMode) {
      document.body.classList.add('print-mode-active');
      window.scrollTo(0, 0);
    } else {
      document.body.classList.remove('print-mode-active');
    }
  }, [isPrintMode]);

  const [loginData, setLoginData] = useState({ name: '', password: '' });
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, expired: 0, warning: 0, inUse: 0 });
  const [searchTerm, setSearchTerm] = useState('');
  const [historySearchTerm, setHistorySearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'VENCIDO' | 'ALERTA' | 'NA_FILA'>('all');
  const [loading, setLoading] = useState(false);

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isMoveModalOpen, setIsMoveModalOpen] = useState(false);
  const [isCalibrateModalOpen, setIsCalibrateModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isGlobalMoveModalOpen, setIsGlobalMoveModalOpen] = useState(false);
  const [selectedInstrument, setSelectedInstrument] = useState<Instrument | null>(null);
  const [historyData, setHistoryData] = useState<{ calibrations: any[], movements: any[] }>({ calibrations: [], movements: [] });
  const [globalHistory, setGlobalHistory] = useState<{ calibrations: any[], movements: any[] }>({ calibrations: [], movements: [] });
  const [operators, setOperators] = useState<any[]>([]);
  const [isOperatorModalOpen, setIsOperatorModalOpen] = useState(false);
  const [operatorFormData, setOperatorFormData] = useState({ name: '', sector: 'Produção', machine: '' });
  const [reportView, setReportView] = useState<'none' | 'inventory' | 'schedule' | 'expired' | 'expired_alerts' | 'operators' | 'packing_list_instruments' | 'packing_list_gauges'>('none');
  const [selectedForPackingList, setSelectedForPackingList] = useState<number[]>([]);
  const [packingListOnlyExpired, setPackingListOnlyExpired] = useState(false);
  const [companySettings, setCompanySettings] = useState({
    name: 'AGM Usinagem de Precisão & Ends',
    address: 'Rua da Usinagem, 123 - Distrito Industrial',
    contact: '(11) 4002-8922 / contato@agmusinagem.com.br',
    responsible: 'Jefferson Vieira Xavier'
  });

  const [packingListSettings, setPackingListSettings] = useState({
    destination: 'INSTITUTO DE METROLOGIA INDUSTRIAL - IMI',
    responsible: 'Jefferson Vieira Xavier'
  });

  useEffect(() => {
    setIsPrintMode(false);
    setPackingListOnlyExpired(false);
  }, [activeTab, reportView]);

  // Form States
  const [formData, setFormData] = useState({
    code: '', type: '', description: '', range: '', manufacturer: '', category: 'Instrumentos', last_calibration: '', periodicity_months: '12', current_sector: 'Instrumentação'
  });
  const [moveData, setMoveData] = useState({ to_sector: '', responsible: '' });
  const [calibrateData, setCalibrateData] = useState({ date: new Date().toISOString().split('T')[0], result: 'APROVADO', responsible: '', notes: '' });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [instRes, statsRes] = await Promise.all([
        fetch('/api/instruments'),
        fetch('/api/stats')
      ]);
      const instData = await instRes.json();
      const statsData = await statsRes.json();
      setInstruments(instData);
      setStats(statsData);
      
      const historyRes = await fetch('/api/history/all');
      const historyData = await historyRes.json();
      setGlobalHistory(historyData);

      const operatorsRes = await fetch('/api/operators');
      const operatorsData = await operatorsRes.json();
      setOperators(operatorsData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddOperator = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/operators', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(operatorFormData)
      });
      if (res.ok) {
        setIsOperatorModalOpen(false);
        setOperatorFormData({ name: '', sector: 'Produção', machine: '' });
        fetchData();
      }
    } catch (error) {
      console.error("Error adding operator:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteOperator = async (id: number) => {
    if (!confirm("Deseja realmente excluir este operador?")) return;
    try {
      await fetch(`/api/operators/${id}`, { method: 'DELETE' });
      fetchData();
    } catch (error) {
      console.error("Error deleting operator:", error);
    }
  };

  const handleAddInstrument = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/instruments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        setIsAddModalOpen(false);
        fetchData();
        setFormData({ code: '', type: '', description: '', range: '', manufacturer: '', category: 'Instrumentos', last_calibration: '', periodicity_months: '12', current_sector: 'Instrumentação' });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleMoveInstrument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInstrument) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/instruments/${selectedInstrument.id}/move`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(moveData)
      });
      if (res.ok) {
        setIsMoveModalOpen(false);
        fetchData();
        setMoveData({ to_sector: '', responsible: '' });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCalibrateInstrument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInstrument) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/instruments/${selectedInstrument.id}/calibrate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(calibrateData)
      });
      if (res.ok) {
        setIsCalibrateModalOpen(false);
        fetchData();
        setCalibrateData({ date: new Date().toISOString().split('T')[0], result: 'APROVADO', responsible: '', notes: '' });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchHistory = async (inst: Instrument) => {
    setSelectedInstrument(inst);
    try {
      const res = await fetch(`/api/instruments/${inst.id}/history`);
      const data = await res.json();
      setHistoryData(data);
      setIsHistoryModalOpen(true);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    console.log("Tentando login com:", loginData.name);
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData)
      });
      
      if (res.ok) {
        const userData = await res.json();
        console.log("Login bem-sucedido:", userData.name);
        setUser(userData);
      } else {
        const errorData = await res.json();
        console.log("Falha no login:", errorData.error);
        alert(errorData.error || "Credenciais inválidas");
      }
    } catch (error) {
      console.error("Erro na requisição de login:", error);
      alert("Erro ao conectar ao servidor. Verifique se o backend está rodando.");
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md glass-card p-8"
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-blue-900 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-blue-900/20">
              <span className="text-white font-black text-xl tracking-tighter">AGM</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight">METROFLOW - Setor Instrumentação</h1>
            <p className="text-slate-500 text-sm">AGM Usinagem de Precisão & Ends</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Usuário</label>
              <input 
                type="text" 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                placeholder="Seu nome"
                value={loginData.name}
                onChange={e => setLoginData({ ...loginData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Senha</label>
              <input 
                type="password" 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                placeholder="••••••••"
                value={loginData.password}
                onChange={e => setLoginData({ ...loginData, password: e.target.value })}
                required
              />
            </div>
            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-semibold py-3 rounded-xl shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Autenticando...
                </>
              ) : (
                "Acessar Sistema"
              )}
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen flex bg-slate-50 dark:bg-slate-950 ${isPrintMode ? 'print-preview' : ''}`}>
      {/* Sidebar */}
      <aside className={`w-72 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col no-print ${isPrintMode ? 'hidden' : ''}`}>
        <div className="flex items-center gap-3 mb-10 px-2">
                <div className="w-10 h-10 bg-blue-900 rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/20">
            <span className="text-white font-black text-xs tracking-tighter">AGM</span>
          </div>
          <div>
            <h2 className="font-bold tracking-tight leading-none text-sm">METROFLOW - Setor Instrumentação</h2>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <SidebarItem icon={Box} label="Instrumentos" active={activeTab === 'instruments'} onClick={() => setActiveTab('instruments')} />
          <SidebarItem icon={Box} label="Calibres" active={activeTab === 'gauges'} onClick={() => setActiveTab('gauges')} />
          <SidebarItem icon={FileText} label="Relatórios" active={activeTab === 'reports'} onClick={() => setActiveTab('reports')} />
          <SidebarItem icon={Users} label="Operadores" active={activeTab === 'operators'} onClick={() => setActiveTab('operators')} />
          <SidebarItem icon={History} label="Calibração" active={activeTab === 'calibration'} onClick={() => setActiveTab('calibration')} />
          <SidebarItem icon={ArrowRightLeft} label="Movimentações" active={activeTab === 'movements'} onClick={() => setActiveTab('movements')} />
          <SidebarItem icon={Settings} label="Configurações" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3 mb-6 px-2">
            <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
              <UserIcon size={20} className="text-slate-500" />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold truncate">{user.name}</p>
              <p className="text-[10px] text-slate-500 uppercase font-bold">{user.role}</p>
            </div>
          </div>
          <button 
            onClick={() => setUser(null)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all"
          >
            <LogOut size={20} />
            <span className="font-medium">Sair</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 overflow-y-auto p-8 ${isPrintMode ? 'p-0' : ''}`}>
        <header className="flex items-center justify-between mb-8 no-print">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              {activeTab === 'dashboard' && 'Visão Geral'}
              {activeTab === 'instruments' && 'Gestão de Instrumentos'}
              {activeTab === 'gauges' && 'Gestão de Calibres'}
              {activeTab === 'reports' && 'Relatórios e Inteligência'}
              {activeTab === 'operators' && 'Gestão de Operadores'}
              {activeTab === 'calibration' && 'Histórico de Calibração'}
              {activeTab === 'movements' && 'Rastreabilidade'}
            </h1>
            <p className="text-slate-500 text-sm">Bem-vindo de volta, {user.name.split(' ')[0]}</p>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 transition-all hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Buscar instrumento..."
                className="pl-11 pr-4 py-3 w-64 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard label="Total de Itens" value={stats.total} icon={Box} colorClass="bg-slate-800" />
                <StatCard label="Vencidos" value={stats.expired} icon={AlertTriangle} colorClass="bg-red-500" />
                <StatCard label="Próximos (30d)" value={stats.warning} icon={Clock} colorClass="bg-amber-500" />
                <StatCard label="Em Uso / Campo" value={stats.inUse} icon={UserIcon} colorClass="bg-blue-600" />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 glass-card p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-bold text-lg">Instrumentos Recentes</h3>
                    <button onClick={() => setActiveTab('instruments')} className="text-blue-600 text-sm font-bold hover:underline">Ver todos</button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100 dark:border-slate-800">
                          <th className="pb-4 px-2">Código</th>
                          <th className="pb-4 px-2">Descrição</th>
                          <th className="pb-4 px-2">Setor</th>
                          <th className="pb-4 px-2">Status</th>
                          <th className="pb-4 px-2">Próxima</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                        {instruments.slice(0, 5).map((inst) => (
                          <tr key={inst.id} className="text-sm hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                            <td className="py-4 px-2 font-mono font-bold">{inst.code}</td>
                            <td className="py-4 px-2">{inst.description}</td>
                            <td className="py-4 px-2">
                              <span className="flex items-center gap-1.5 text-slate-500">
                                <MapPin size={14} />
                                {inst.current_sector}
                              </span>
                            </td>
                            <td className="py-4 px-2">
                              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                                inst.status === 'OK' ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400' :
                                inst.status === 'VENCIDO' ? 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400' :
                                'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400'
                              }`}>
                                {inst.status}
                              </span>
                            </td>
                            <td className="py-4 px-2 text-slate-500">{new Date(inst.next_calibration).toLocaleDateString('pt-BR')}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="glass-card p-6">
                  <h3 className="font-bold text-lg mb-6">Ações Rápidas</h3>
                  <div className="space-y-3">
                    <button 
                      onClick={() => setIsAddModalOpen(true)}
                      className="w-full flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-blue-600 hover:text-white transition-all group"
                    >
                      <div className="flex items-center gap-3">
                        <Plus size={20} />
                        <span className="font-medium">Novo Instrumento</span>
                      </div>
                      <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                    <button 
                      onClick={() => setIsGlobalMoveModalOpen(true)}
                      className="w-full flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-blue-600 hover:text-white transition-all group"
                    >
                      <div className="flex items-center gap-3">
                        <ArrowRightLeft size={20} />
                        <span className="font-medium">Movimentar Item</span>
                      </div>
                      <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                    <button 
                      onClick={() => setActiveTab('reports')}
                      className="w-full flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-blue-600 hover:text-white transition-all group"
                    >
                      <div className="flex items-center gap-3">
                        <FileText size={20} />
                        <span className="font-medium">Gerar Relatório</span>
                      </div>
                      <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'reports' && (
            <motion.div 
              key="reports"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {reportView === 'none' ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <ReportCard 
                      title="Inventário Geral" 
                      desc="Lista completa de ativos e localização." 
                      icon={FileText} 
                      color="blue" 
                      onClick={() => setReportView('inventory')} 
                    />
                    <ReportCard 
                      title="Cronograma" 
                      desc="Itens a vencer nos próximos 90 dias." 
                      icon={Clock} 
                      color="indigo" 
                      onClick={() => setReportView('schedule')} 
                    />
                    <ReportCard 
                      title="Vencidos e Alertas" 
                      desc="Apenas itens que exigem atenção imediata." 
                      icon={AlertTriangle} 
                      color="red" 
                      onClick={() => setReportView('expired_alerts')} 
                    />
                    <ReportCard 
                      title="Itens Vencidos" 
                      desc="Relatório de ação imediata (Qualidade)." 
                      icon={AlertTriangle} 
                      color="red" 
                      onClick={() => setReportView('expired')} 
                    />
                    <ReportCard 
                      title="Por Máquina" 
                      desc="Distribuição de calibres por posto." 
                      icon={Users} 
                      color="amber" 
                      onClick={() => setReportView('operators')} 
                    />
                    <ReportCard 
                      title="Romaneio: Instrumentos" 
                      desc="Lista de envio de instrumentos para laboratório." 
                      icon={Package} 
                      color="blue" 
                      onClick={() => setReportView('packing_list_instruments')} 
                    />
                    <ReportCard 
                      title="Romaneio: Calibres" 
                      desc="Lista de envio de calibres para laboratório." 
                      icon={Package} 
                      color="indigo" 
                      onClick={() => setReportView('packing_list_gauges')} 
                    />
                  </div>

                  <div className="glass-card p-8 bg-white dark:bg-slate-900 border-2 border-dashed border-slate-200 dark:border-slate-800">
                    <div className="text-center max-w-md mx-auto">
                      <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Search size={32} className="text-slate-400" />
                      </div>
                      <h3 className="font-bold text-xl mb-2">Inteligência de Dados</h3>
                      <p className="text-slate-500 mb-6">Como especialista em usinagem, o sistema analisa o desgaste e sugere ajustes na periodicidade para reduzir custos de calibração externa.</p>
                      <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: '85%' }}
                          className="h-full bg-blue-600"
                        />
                      </div>
                      <p className="text-[10px] uppercase font-bold text-slate-400 mt-4 tracking-widest">Análise de Confiabilidade Metrológica AGM</p>
                    </div>
                  </div>
                </>
              ) : (
                <div className={`${isPrintMode ? 'preview-mode' : 'space-y-6'}`}>
                  {isPrintMode && (
                    <div className="fixed top-0 left-0 right-0 h-16 bg-slate-900/90 backdrop-blur-md z-[100] flex items-center justify-between px-8 no-print">
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-black text-xs">AGM</div>
                        <p className="text-white font-bold text-sm">Pré-visualização do Relatório</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => setIsPrintMode(false)}
                          className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg font-bold hover:bg-slate-700 transition-all flex items-center gap-2"
                        >
                          <ChevronRight className="rotate-180" size={18} />
                          Voltar
                        </button>
                        <button 
                          onClick={() => window.print()}
                          className="px-6 py-2 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2"
                        >
                          <Printer size={18} />
                          Imprimir em PDF
                        </button>
                      </div>
                    </div>
                  )}

                  {!isPrintMode && (
                    <div className="flex items-center justify-between no-print">
                      <button 
                        onClick={() => setReportView('none')}
                        className="flex items-center gap-2 text-slate-500 hover:text-slate-800 font-bold text-sm"
                      >
                        <ChevronRight className="rotate-180" size={18} />
                        Voltar aos Relatórios
                      </button>
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => setIsPrintMode(true)}
                          className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                        >
                          <Search size={18} />
                          Prévia de Impressão
                        </button>
                        <button 
                          onClick={() => {
                            if (reportView.startsWith('packing_list') && selectedForPackingList.length === 0) {
                              alert('Por favor, selecione ao menos um item para o romaneio antes de imprimir.');
                              return;
                            }
                            window.print();
                          }}
                          className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all active:scale-95"
                        >
                          <FileText size={18} />
                          Imprimir em PDF
                        </button>
                      </div>
                    </div>
                  )}

                  <div className={`${isPrintMode ? 'report-page-container' : 'glass-card p-8 bg-white dark:bg-slate-900'}`}>
                    {/* Print Header */}
                    <div className="print-header">
                      {reportView.startsWith('packing_list') ? (
                        <div className="border-2 border-slate-900 p-4 mb-6">
                          <div className="flex items-center justify-between mb-6 border-b-2 border-slate-900 pb-4">
                            <div className="flex flex-col items-start">
                              <div className="flex gap-1 mb-1">
                                <div className="w-8 h-8 bg-[#0070f3] flex items-center justify-center shadow-[2px_2px_0px_#000] border border-black">
                                  <span className="text-black font-black text-xl leading-none">A</span>
                                </div>
                                <div className="w-8 h-8 bg-[#0070f3] flex items-center justify-center shadow-[2px_2px_0px_#000] border border-black">
                                  <span className="text-black font-black text-xl leading-none">G</span>
                                </div>
                                <div className="w-8 h-8 bg-[#0070f3] flex items-center justify-center shadow-[2px_2px_0px_#000] border border-black">
                                  <span className="text-black font-black text-xl leading-none">M</span>
                                </div>
                              </div>
                              <p className="text-[9px] font-bold text-black whitespace-nowrap">Usinagem de Precisão & Ends</p>
                            </div>
                            <div className="text-center">
                              <h1 className="text-lg font-black tracking-tight uppercase">Romaneio de Instrumentos</h1>
                            </div>
                            <div className="flex items-center text-right">
                              <div className="flex flex-col items-end">
                                <div className="flex items-baseline gap-0.5">
                                  <span className="text-3xl font-black text-blue-900 tracking-tighter">ARU</span>
                                  <div className="relative inline-block w-10 h-8 -mb-1.5">
                                    <svg viewBox="0 0 64 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-blue-900 w-full h-full">
                                      <path d="M10 8H40V24H10C6 24 2 20 2 16C2 12 6 8 10 8Z" stroke="currentColor" strokeWidth="4"/>
                                      <rect x="40" y="12" width="12" height="8" stroke="currentColor" strokeWidth="4"/>
                                      <path d="M52 16H62" stroke="currentColor" strokeWidth="4"/>
                                      <path d="M10 12V20" stroke="currentColor" strokeWidth="3"/>
                                    </svg>
                                  </div>
                                  <span className="text-3xl font-black text-blue-900 tracking-tighter">Si</span>
                                </div>
                                <div className="w-full text-right mt-0.5">
                                  <p className="text-[7px] font-black text-blue-900 uppercase leading-tight">
                                    Indústria e Comércio<br />de Usinagem
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-2 text-xs font-bold uppercase">
                            <div className="flex gap-2 border-b border-slate-200 pb-1">
                              <span className="text-slate-500 shrink-0">Remetente Responsável:</span>
                              <span className="text-slate-900">{packingListSettings.responsible}</span>
                            </div>
                            <div className="flex gap-2">
                              <span className="text-slate-500 shrink-0">Empresa Destinatária:</span>
                              <span className="text-slate-900">{packingListSettings.destination}</span>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 bg-blue-900 rounded-xl flex items-center justify-center text-white">
                              <span className="font-black text-xs tracking-tighter">AGM</span>
                            </div>
                            <div className="text-center">
                              <h1 className="text-xl font-bold tracking-tight">METROFLOW - Setor Instrumentação</h1>
                              <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">{companySettings.name}</p>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-8 w-full text-[10px] border-t border-slate-100 pt-4">
                            <div>
                              <p className="font-bold text-slate-400 uppercase mb-1">Dados do Cliente</p>
                              <p className="font-bold text-slate-900">{companySettings.name}</p>
                              <p>{companySettings.address}</p>
                              <p>{companySettings.contact}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-slate-400 uppercase mb-1">Responsável</p>
                              <p className="font-bold text-slate-900">{companySettings.responsible}</p>
                              <p>Data de Emissão: {new Date().toLocaleDateString('pt-BR')}</p>
                            </div>
                          </div>
                        </>
                      )}
                    </div>

                    <div className="mb-8 border-b border-slate-100 dark:border-slate-800 pb-6 no-print">
                      <h2 className="text-2xl font-bold">
                        {reportView === 'inventory' && 'Relatório: Inventário Geral de Ativos'}
                        {reportView === 'schedule' && 'Relatório: Cronograma de Calibração (90 dias)'}
                        {reportView === 'expired' && 'Relatório: Itens com Calibração Vencida'}
                        {reportView === 'expired_alerts' && 'Relatório: Itens Vencidos e em Alerta'}
                        {reportView === 'operators' && 'Relatório: Distribuição por Máquina/Operador'}
                        {reportView === 'packing_list_instruments' && 'Romaneio de Envio: Instrumentos'}
                        {reportView === 'packing_list_gauges' && 'Romaneio de Envio: Calibres'}
                      </h2>
                      <p className="text-slate-500">Gerado em {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}</p>
                      { (reportView === 'packing_list_instruments' || reportView === 'packing_list_gauges') && (
                        <div className="mt-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-xl text-xs grid grid-cols-2 gap-6 no-print">
                          <div className="space-y-3">
                            <p className="font-bold text-slate-400 uppercase mb-1">Configurações do Romaneio</p>
                            <div className="grid grid-cols-1 gap-3">
                              <div>
                                <label className="block text-[10px] text-slate-400 uppercase mb-1">Empresa Destinatária</label>
                                <input 
                                  type="text" 
                                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600"
                                  value={packingListSettings.destination}
                                  onChange={e => setPackingListSettings({...packingListSettings, destination: e.target.value})}
                                />
                              </div>
                              <div>
                                <label className="block text-[10px] text-slate-400 uppercase mb-1">Remetente Responsável</label>
                                <input 
                                  type="text" 
                                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600"
                                  value={packingListSettings.responsible}
                                  onChange={e => setPackingListSettings({...packingListSettings, responsible: e.target.value})}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="text-right flex flex-col justify-between">
                            <div>
                              <p className="font-bold text-slate-400 uppercase mb-1">Seleção de Itens</p>
                              <p>Selecione os itens abaixo para incluir no romaneio.</p>
                              <div className="flex items-center justify-end gap-3 mt-2">
                                <button 
                                  onClick={() => {
                                    const nextState = !packingListOnlyExpired;
                                    setPackingListOnlyExpired(nextState);
                                    
                                    if (nextState) {
                                      const targetIds = instruments
                                        .filter(i => {
                                          const isMatch = reportView === 'packing_list_gauges' 
                                            ? i.category.startsWith('Calibres')
                                            : !i.category.startsWith('Calibres');
                                          return isMatch && (i.status === 'VENCIDO' || i.status === 'ALERTA');
                                        })
                                        .map(i => i.id);
                                      setSelectedForPackingList(targetIds);
                                    }
                                  }}
                                  className={`${packingListOnlyExpired ? 'text-red-700 bg-red-50 px-2 py-0.5 rounded border border-red-200' : 'text-red-600'} font-bold hover:underline`}
                                >
                                  {packingListOnlyExpired ? 'Ver Todos os Itens' : 'Filtrar Vencidos e Alertas'}
                                </button>
                                <span className="h-3 w-px bg-slate-300"></span>
                                <button 
                                  onClick={() => {
                                    const filtered = instruments.filter(i => {
                                      return reportView === 'packing_list_gauges' 
                                        ? i.category.startsWith('Calibres')
                                        : !i.category.startsWith('Calibres');
                                    });
                                    if (selectedForPackingList.length === filtered.length) {
                                      setSelectedForPackingList([]);
                                    } else {
                                      setSelectedForPackingList(filtered.map(i => i.id));
                                    }
                                  }}
                                  className="text-blue-600 font-bold hover:underline"
                                >
                                  {selectedForPackingList.length > 0 ? 'Desmarcar Todos' : 'Selecionar Todos'}
                                </button>
                              </div>
                            </div>
                            <div className="mt-4">
                              <p>Total selecionado: <span className="font-bold text-blue-600">{selectedForPackingList.length} itens</span></p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <table className="w-full text-left text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase text-[10px] font-bold tracking-widest">
                          {(reportView === 'packing_list_instruments' || reportView === 'packing_list_gauges') && <th className="py-3 px-2 no-print">Sel.</th>}
                          <th className="py-3 px-2">Código</th>
                          <th className="py-3 px-2">Descrição / Faixa</th>
                          {(reportView === 'packing_list_instruments' || reportView === 'packing_list_gauges') && isPrintMode ? (
                            <th className="py-3 px-2">Fabricante</th>
                          ) : (
                            <>
                              <th className="py-3 px-2">Localização / Máquina</th>
                              <th className="py-3 px-2">Status</th>
                              <th className="py-3 px-2">Vencimento</th>
                            </>
                          )}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                        {instruments
                          .filter(i => {
                            if (reportView === 'expired') return i.status === 'VENCIDO';
                            if (reportView === 'expired_alerts') return i.status === 'VENCIDO' || i.status === 'ALERTA';
                            if (reportView === 'schedule') {
                              const next = new Date(i.next_calibration);
                              const limit = new Date();
                              limit.setDate(limit.getDate() + 90);
                              return next <= limit && i.status !== 'VENCIDO';
                            }
                            if (reportView === 'packing_list_instruments') {
                              const isInstrument = !i.category.startsWith('Calibres');
                              if (packingListOnlyExpired) {
                                return isInstrument && (i.status === 'VENCIDO' || i.status === 'ALERTA');
                              }
                              return isInstrument;
                            }
                            if (reportView === 'packing_list_gauges') {
                              const isGauge = i.category.startsWith('Calibres');
                              if (packingListOnlyExpired) {
                                return isGauge && (i.status === 'VENCIDO' || i.status === 'ALERTA');
                              }
                              return isGauge;
                            }
                            return true;
                          })
                          .map(inst => (
                            <tr key={inst.id} className={(reportView === 'packing_list_instruments' || reportView === 'packing_list_gauges') && !selectedForPackingList.includes(inst.id) ? 'no-print' : ''}>
                              {(reportView === 'packing_list_instruments' || reportView === 'packing_list_gauges') && (
                                <td className="py-4 px-2 no-print">
                                  <button 
                                    onClick={() => {
                                      if (selectedForPackingList.includes(inst.id)) {
                                        setSelectedForPackingList(selectedForPackingList.filter(id => id !== inst.id));
                                      } else {
                                        setSelectedForPackingList([...selectedForPackingList, inst.id]);
                                      }
                                    }}
                                    className={`p-1 rounded transition-colors ${selectedForPackingList.includes(inst.id) ? 'text-blue-600' : 'text-slate-300'}`}
                                  >
                                    {selectedForPackingList.includes(inst.id) ? <CheckSquare size={20} /> : <Square size={20} />}
                                  </button>
                                </td>
                              )}
                              <td className="py-4 px-2 font-mono font-bold text-blue-600">{inst.code}</td>
                              <td className="py-4 px-2">
                                <p className="font-medium">{inst.description}</p>
                                <p className="text-[10px] text-slate-400">{inst.range}</p>
                              </td>
                              {reportView.startsWith('packing_list') && isPrintMode ? (
                                <td className="py-4 px-2 text-slate-600">{inst.manufacturer}</td>
                              ) : (
                                <>
                                  <td className="py-4 px-2">
                                    <p className="font-medium">{inst.current_sector}</p>
                                    <p className="text-[10px] text-slate-400">{inst.current_responsible || 'Disponível'}</p>
                                  </td>
                                  <td className="py-4 px-2">
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                      inst.status === 'OK' ? 'bg-blue-100 text-blue-700' :
                                      inst.status === 'VENCIDO' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                                    }`}>
                                      {inst.status}
                                    </span>
                                  </td>
                                  <td className="py-4 px-2 font-medium">
                                    {new Date(inst.next_calibration).toLocaleDateString('pt-BR')}
                                  </td>
                                </>
                              )}
                            </tr>
                          ))}
                      </tbody>
                    </table>

                    {/* Print Footer */}
                    {reportView.startsWith('packing_list') ? (
                      <div className="print-only mt-12 space-y-8">
                        <div className="flex justify-between items-end border-t-2 border-slate-900 pt-4">
                          <p className="font-black text-sm uppercase">Total de Itens: {selectedForPackingList.length}</p>
                        </div>
                        
                        <div className="text-center space-y-12">
                          <p className="text-[10px] font-black uppercase tracking-widest">Declaro manter com cuidado e zelo os instrumentos listados acima.</p>
                          
                          <div className="max-w-md mx-auto space-y-2">
                            <div className="border-b-2 border-slate-900 w-full h-px"></div>
                            <p className="text-[10px] font-black uppercase">Destinatário responsável (Nome e Assinatura)</p>
                          </div>
                          
                          <div className="flex justify-center gap-2 text-xs font-bold">
                            <span>Duque De Caxias,</span>
                            <span className="border-b border-slate-900 w-8"></span>
                            <span>/</span>
                            <span className="border-b border-slate-900 w-24"></span>
                            <span>/</span>
                            <span className="border-b border-slate-900 w-12"></span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="print-only mt-12 grid grid-cols-2 gap-12">
                        <div className="border-t border-slate-900 pt-2 text-center">
                          <p className="text-[10px] font-bold uppercase">Responsável AGM (Saída)</p>
                          <p className="text-[8px] text-slate-500 mt-1">Data: ____/____/____</p>
                        </div>
                        <div className="border-t border-slate-900 pt-2 text-center">
                          <p className="text-[10px] font-bold uppercase">Recebido por (Laboratório)</p>
                          <p className="text-[8px] text-slate-500 mt-1">Data: ____/____/____</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          )}
          {activeTab === 'operators' && (
            <motion.div 
              key="operators"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="glass-card p-6"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h3 className="text-lg font-bold">Gestão de Operadores</h3>
                  <p className="text-sm text-slate-500">Cadastre os funcionários e as máquinas onde trabalham.</p>
                </div>
                <button 
                  onClick={() => setIsOperatorModalOpen(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/20"
                >
                  <Plus size={18} />
                  Cadastrar Operador
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100 dark:border-slate-800">
                      <th className="pb-4 px-2">Nome do Operador</th>
                      <th className="pb-4 px-2">Setor</th>
                      <th className="pb-4 px-2">Máquina / Posto</th>
                      <th className="pb-4 px-2 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                    {operators.map((op) => (
                      <tr key={op.id} className="text-sm hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="py-5 px-2 font-bold">{op.name}</td>
                        <td className="py-5 px-2 text-slate-500">{op.sector}</td>
                        <td className="py-5 px-2">
                          <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg font-mono text-xs font-bold text-blue-600">
                            {op.machine || 'NÃO ATRIBUÍDA'}
                          </span>
                        </td>
                        <td className="py-5 px-2 text-right">
                          <button 
                            onClick={() => handleDeleteOperator(op.id)}
                            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'calibration' && (
            <motion.div 
              key="calibration"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="glass-card p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-lg">Histórico Global de Calibrações</h3>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input 
                    type="text" 
                    placeholder="Buscar no histórico..." 
                    className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600 text-sm"
                    value={historySearchTerm}
                    onChange={(e) => setHistorySearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100 dark:border-slate-800">
                      <th className="pb-4 px-2">Data</th>
                      <th className="pb-4 px-2">Instrumento</th>
                      <th className="pb-4 px-2">Resultado</th>
                      <th className="pb-4 px-2">Responsável</th>
                      <th className="pb-4 px-2">Notas</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                    {globalHistory.calibrations.filter(c => {
                      const inst = instruments.find(i => i.id === c.instrument_id);
                      const search = historySearchTerm.toLowerCase();
                      return inst?.code.toLowerCase().includes(search) || inst?.description.toLowerCase().includes(search) || c.responsible.toLowerCase().includes(search);
                    }).map((c: any) => {
                      const inst = instruments.find(i => i.id === c.instrument_id);
                      return (
                        <tr key={c.id} className="text-sm hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                          <td className="py-4 px-2 font-medium">{new Date(c.date).toLocaleDateString('pt-BR')}</td>
                          <td className="py-4 px-2">
                            <p className="font-bold text-blue-600">{inst?.code || '---'}</p>
                            <p className="text-xs text-slate-500">{inst?.description}</p>
                          </td>
                          <td className="py-4 px-2">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${c.result === 'APROVADO' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'}`}>
                              {c.result}
                            </span>
                          </td>
                          <td className="py-4 px-2 text-slate-600">{c.responsible}</td>
                          <td className="py-4 px-2 text-slate-400 italic text-xs">{c.notes}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'movements' && (
            <motion.div 
              key="movements"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="glass-card p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-lg">Histórico Global de Movimentações</h3>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input 
                    type="text" 
                    placeholder="Buscar no histórico..." 
                    className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600 text-sm"
                    value={historySearchTerm}
                    onChange={(e) => setHistorySearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100 dark:border-slate-800">
                      <th className="pb-4 px-2">Data</th>
                      <th className="pb-4 px-2">Instrumento</th>
                      <th className="pb-4 px-2">Origem</th>
                      <th className="pb-4 px-2">Destino</th>
                      <th className="pb-4 px-2">Responsável</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                    {globalHistory.movements.filter(m => {
                      const inst = instruments.find(i => i.id === m.instrument_id);
                      const search = historySearchTerm.toLowerCase();
                      return inst?.code.toLowerCase().includes(search) || inst?.description.toLowerCase().includes(search) || m.responsible.toLowerCase().includes(search) || m.to_sector.toLowerCase().includes(search);
                    }).map((m: any) => {
                      const inst = instruments.find(i => i.id === m.instrument_id);
                      return (
                        <tr key={m.id} className="text-sm hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                          <td className="py-4 px-2 font-medium">{new Date(m.date).toLocaleString('pt-BR')}</td>
                          <td className="py-4 px-2">
                            <p className="font-bold text-blue-600">{inst?.code || '---'}</p>
                            <p className="text-xs text-slate-500">{inst?.description}</p>
                          </td>
                          <td className="py-4 px-2 text-slate-500">{m.from_sector}</td>
                          <td className="py-4 px-2 font-bold text-blue-600">{m.to_sector}</td>
                          <td className="py-4 px-2 text-slate-600">{m.responsible}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div 
              key="settings"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="glass-card p-8">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center text-slate-500">
                    <Building2 size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Dados da Empresa</h3>
                    <p className="text-sm text-slate-500">Estas informações aparecerão nos cabeçalhos dos relatórios e romaneios.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-slate-400">Nome da Empresa / Unidade</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600"
                      value={companySettings.name}
                      onChange={e => setCompanySettings({...companySettings, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-slate-400">Responsável Metrologia</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600"
                      value={companySettings.responsible}
                      onChange={e => setCompanySettings({...companySettings, responsible: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <label className="text-xs font-bold uppercase text-slate-400">Endereço Completo</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600"
                      value={companySettings.address}
                      onChange={e => setCompanySettings({...companySettings, address: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <label className="text-xs font-bold uppercase text-slate-400">Contatos (Telefone / Email)</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600"
                      value={companySettings.contact}
                      onChange={e => setCompanySettings({...companySettings, contact: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                  <button 
                    onClick={() => {
                      alert('Configurações salvas com sucesso!');
                    }}
                    className="px-6 py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all flex items-center gap-2"
                  >
                    <CheckCircle2 size={18} />
                    Salvar Configurações
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass-card p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-500">
                      <ShieldCheck size={20} />
                    </div>
                    <h4 className="font-bold">Segurança e Backup</h4>
                  </div>
                  <p className="text-sm text-slate-500 mb-6">O banco de dados SQLite é persistente. Recomenda-se exportar o inventário mensalmente como backup de segurança.</p>
                  <button 
                    onClick={() => { setReportView('inventory'); setActiveTab('reports'); }}
                    className="w-full py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
                  >
                    Exportar Backup (CSV/PDF)
                  </button>
                </div>

                <div className="glass-card p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-10 h-10 bg-amber-100 dark:bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-500">
                      <Moon size={20} />
                    </div>
                    <h4 className="font-bold">Preferências de Exibição</h4>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-500">Modo Escuro (Dark Mode)</span>
                    <button 
                      onClick={() => setIsDarkMode(!isDarkMode)}
                      className={`w-12 h-6 rounded-full transition-all relative ${isDarkMode ? 'bg-blue-600' : 'bg-slate-200'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${isDarkMode ? 'left-7' : 'left-1'}`} />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
          {activeTab === 'instruments' && (
            <motion.div 
              key="instruments"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="glass-card p-6"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                    <button onClick={() => setFilterStatus('all')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'all' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-500'}`}>TODOS</button>
                    <button onClick={() => setFilterStatus('VENCIDO')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'VENCIDO' ? 'bg-red-500 text-white shadow-sm' : 'text-slate-500'}`}>VENCIDOS</button>
                    <button onClick={() => setFilterStatus('ALERTA')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'ALERTA' ? 'bg-amber-500 text-white shadow-sm' : 'text-slate-500'}`}>A VENCER</button>
                    <button onClick={() => setFilterStatus('NA_FILA')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'NA_FILA' ? 'bg-indigo-500 text-white shadow-sm' : 'text-slate-500'}`}>NA FILA</button>
                  </div>
                  <div className="h-6 w-px bg-slate-200 dark:border-slate-800"></div>
                  <p className="text-sm text-slate-500">
                    {instruments
                      .filter(i => !i.category.startsWith('Calibres'))
                      .filter(i => {
                        if (filterStatus === 'all') return true;
                        if (filterStatus === 'NA_FILA') return i.notes?.toUpperCase().includes('FILA');
                        return i.status === filterStatus;
                      }).length} instrumentos
                  </p>
                </div>
                <button 
                  onClick={() => { setFormData({...formData, category: 'Instrumentos'}); setIsAddModalOpen(true); }}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/20"
                >
                  <Plus size={18} />
                  Cadastrar Instrumento
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100 dark:border-slate-800">
                      <th className="pb-4 px-2">Código</th>
                      <th className="pb-4 px-2">Descrição</th>
                      <th className="pb-4 px-2">Categoria</th>
                      <th className="pb-4 px-2">Setor / Responsável</th>
                      <th className="pb-4 px-2">Status</th>
                      <th className="pb-4 px-2">Próxima Calibração</th>
                      <th className="pb-4 px-2 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                    {instruments
                      .filter(i => !i.category.startsWith('Calibres'))
                      .filter(i => {
                        if (filterStatus === 'all') return true;
                        if (filterStatus === 'NA_FILA') return i.notes?.toUpperCase().includes('FILA');
                        return i.status === filterStatus;
                      })
                      .filter(i => i.code.toLowerCase().includes(searchTerm.toLowerCase()) || i.description.toLowerCase().includes(searchTerm.toLowerCase()))
                      .map((inst) => (
                      <tr key={inst.id} className="text-sm hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="py-5 px-2 font-mono font-bold text-blue-600 dark:text-blue-400">{inst.code}</td>
                        <td className="py-5 px-2">
                          <p className="font-medium">{inst.description}</p>
                          <p className="text-[10px] text-slate-400 uppercase">{inst.manufacturer} • {inst.range}</p>
                        </td>
                        <td className="py-5 px-2 text-slate-500">{inst.category}</td>
                        <td className="py-5 px-2">
                          <p className="text-slate-700 dark:text-slate-300 font-medium">{inst.current_sector}</p>
                          <p className="text-xs text-slate-400">{inst.current_responsible || 'Disponível'}</p>
                          {inst.notes && <p className="text-[10px] text-amber-600 font-bold mt-1 uppercase">{inst.notes}</p>}
                        </td>
                        <td className="py-5 px-2">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                            inst.status === 'OK' ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400' :
                            inst.status === 'VENCIDO' ? 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400' :
                            'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400'
                          }`}>
                            {inst.status}
                          </span>
                        </td>
                        <td className="py-5 px-2">
                          <p className="font-medium">{inst.next_calibration ? new Date(inst.next_calibration).toLocaleDateString('pt-BR') : '---'}</p>
                          <p className="text-[10px] text-slate-400 uppercase">Última: {inst.last_calibration ? new Date(inst.last_calibration).toLocaleDateString('pt-BR') : '---'}</p>
                          <p className="text-[10px] text-slate-400 uppercase">Período: {inst.periodicity_months}m</p>
                        </td>
                        <td className="py-5 px-2 text-right">
                          <button 
                            onClick={() => { setSelectedInstrument(inst); setIsMoveModalOpen(true); }}
                            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-blue-600 transition-colors"
                            title="Movimentar"
                          >
                            <ArrowRightLeft size={18} />
                          </button>
                          <button 
                            onClick={() => { setSelectedInstrument(inst); setIsCalibrateModalOpen(true); }}
                            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-blue-600 transition-colors"
                            title="Calibrar"
                          >
                            <CheckCircle2 size={18} />
                          </button>
                          <button 
                            onClick={() => fetchHistory(inst)}
                            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-blue-600 transition-colors"
                            title="Histórico"
                          >
                            <History size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'gauges' && (
            <motion.div 
              key="gauges"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="glass-card p-6"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                    <button onClick={() => setFilterStatus('all')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'all' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'text-slate-500'}`}>TODOS</button>
                    <button onClick={() => setFilterStatus('VENCIDO')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'VENCIDO' ? 'bg-red-500 text-white shadow-sm' : 'text-slate-500'}`}>VENCIDOS</button>
                    <button onClick={() => setFilterStatus('ALERTA')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'ALERTA' ? 'bg-amber-500 text-white shadow-sm' : 'text-slate-500'}`}>A VENCER</button>
                    <button onClick={() => setFilterStatus('NA_FILA')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${filterStatus === 'NA_FILA' ? 'bg-indigo-500 text-white shadow-sm' : 'text-slate-500'}`}>NA FILA</button>
                  </div>
                  <div className="h-6 w-px bg-slate-200 dark:border-slate-800"></div>
                  <p className="text-sm text-slate-500">
                    {instruments
                      .filter(i => i.category.startsWith('Calibres'))
                      .filter(i => {
                        if (filterStatus === 'all') return true;
                        if (filterStatus === 'NA_FILA') return i.notes?.toUpperCase().includes('FILA');
                        return i.status === filterStatus;
                      }).length} calibres
                  </p>
                </div>
                <button 
                  onClick={() => { setFormData({...formData, category: 'Calibres Anel'}); setIsAddModalOpen(true); }}
                  className="flex items-center gap-2 px-4 py-2 bg-indigo-500 text-white rounded-lg text-sm font-bold hover:bg-indigo-600 transition-colors shadow-lg shadow-indigo-500/20"
                >
                  <Plus size={18} />
                  Cadastrar Calibre
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-slate-400 text-xs uppercase font-bold tracking-wider border-b border-slate-100 dark:border-slate-800">
                      <th className="pb-4 px-2">Código</th>
                      <th className="pb-4 px-2">Descrição</th>
                      <th className="pb-4 px-2">Categoria</th>
                      <th className="pb-4 px-2">Setor / Responsável</th>
                      <th className="pb-4 px-2">Status</th>
                      <th className="pb-4 px-2">Próxima Calibração</th>
                      <th className="pb-4 px-2 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                    {instruments
                      .filter(i => i.category.startsWith('Calibres'))
                      .filter(i => {
                        if (filterStatus === 'all') return true;
                        if (filterStatus === 'NA_FILA') return i.notes?.toUpperCase().includes('FILA');
                        return i.status === filterStatus;
                      })
                      .filter(i => i.code.toLowerCase().includes(searchTerm.toLowerCase()) || i.description.toLowerCase().includes(searchTerm.toLowerCase()))
                      .map((inst) => (
                      <tr key={inst.id} className="text-sm hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="py-5 px-2 font-mono font-bold text-indigo-600 dark:text-indigo-400">{inst.code}</td>
                        <td className="py-5 px-2">
                          <p className="font-medium">{inst.description}</p>
                          <p className="text-[10px] text-slate-400 uppercase">{inst.manufacturer} • {inst.range}</p>
                        </td>
                        <td className="py-5 px-2 text-slate-500">{inst.category}</td>
                        <td className="py-5 px-2">
                          <p className="text-slate-700 dark:text-slate-300 font-medium">{inst.current_sector}</p>
                          <p className="text-xs text-slate-400">{inst.current_responsible || 'Disponível'}</p>
                          {inst.notes && <p className="text-[10px] text-amber-600 font-bold mt-1 uppercase">{inst.notes}</p>}
                        </td>
                        <td className="py-5 px-2">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                            inst.status === 'OK' ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400' :
                            inst.status === 'VENCIDO' ? 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400' :
                            'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400'
                          }`}>
                            {inst.status}
                          </span>
                        </td>
                        <td className="py-5 px-2">
                          <p className="font-medium">{inst.next_calibration ? new Date(inst.next_calibration).toLocaleDateString('pt-BR') : '---'}</p>
                          <p className="text-[10px] text-slate-400 uppercase">Última: {inst.last_calibration ? new Date(inst.last_calibration).toLocaleDateString('pt-BR') : '---'}</p>
                          <p className="text-[10px] text-slate-400 uppercase">Período: {inst.periodicity_months}m</p>
                        </td>
                        <td className="py-5 px-2 text-right">
                          <button 
                            onClick={() => { setSelectedInstrument(inst); setIsMoveModalOpen(true); }}
                            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-blue-600 transition-colors"
                            title="Movimentar"
                          >
                            <ArrowRightLeft size={18} />
                          </button>
                          <button 
                            onClick={() => { setSelectedInstrument(inst); setIsCalibrateModalOpen(true); }}
                            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-blue-600 transition-colors"
                            title="Calibrar"
                          >
                            <CheckCircle2 size={18} />
                          </button>
                          <button 
                            onClick={() => fetchHistory(inst)}
                            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-blue-600 transition-colors"
                            title="Histórico"
                          >
                            <History size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Print Only Footer */}
        <div className="print-footer">
          <p>© {new Date().getFullYear()} METROFLOW - Setor Instrumentação - Sistema de Gestão de Instrumentação e Usinagem</p>
          <p className="mt-1">Documento gerado eletronicamente. As informações contidas neste relatório são de uso restrito.</p>
        </div>
      </main>

      {/* Modals */}
      <Modal isOpen={isOperatorModalOpen} onClose={() => setIsOperatorModalOpen(false)} title="Cadastrar Operador / Funcionário">
        <form onSubmit={handleAddOperator} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Nome Completo</label>
            <input 
              type="text" 
              className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" 
              value={operatorFormData.name} 
              onChange={e => setOperatorFormData({...operatorFormData, name: e.target.value})} 
              required 
              placeholder="Ex: João Silva"
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Setor</label>
            <input 
              type="text" 
              className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" 
              value={operatorFormData.sector} 
              onChange={e => setOperatorFormData({...operatorFormData, sector: e.target.value})} 
              required 
              placeholder="Ex: Produção, Usinagem..."
            />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Máquina de Trabalho</label>
            <input 
              type="text" 
              className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" 
              value={operatorFormData.machine} 
              onChange={e => setOperatorFormData({...operatorFormData, machine: e.target.value})} 
              required 
              placeholder="Ex: MAQUINA- CE 05"
            />
          </div>
          <button type="submit" className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all">Salvar Operador</button>
        </form>
      </Modal>

      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Novo Instrumento">
        <form onSubmit={handleAddInstrument} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Código</label>
              <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} required />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Tipo</label>
              <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})} required />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Descrição</label>
            <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Faixa</label>
              <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.range} onChange={e => setFormData({...formData, range: e.target.value})} />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Fabricante</label>
              <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.manufacturer} onChange={e => setFormData({...formData, manufacturer: e.target.value})} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Última Calibração</label>
              <input type="date" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.last_calibration} onChange={e => setFormData({...formData, last_calibration: e.target.value})} required />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Periodicidade (Meses)</label>
              <input type="number" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.periodicity_months} onChange={e => setFormData({...formData, periodicity_months: e.target.value})} required />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Categoria</label>
              <select 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" 
                value={formData.category} 
                onChange={e => setFormData({...formData, category: e.target.value})}
              >
                <option value="Instrumentos">Instrumentos</option>
                <option value="Calibres Anel">Calibres Anel</option>
                <option value="Calibres Tampão">Calibres Tampão</option>
                <option value="Hastes Padrão">Hastes Padrão</option>
                <option value="Durômetros / Blocos">Durômetros / Blocos</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Setor Inicial</label>
              <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={formData.current_sector} onChange={e => setFormData({...formData, current_sector: e.target.value})} required />
            </div>
          </div>
          <button type="submit" className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all">Salvar Registro</button>
        </form>
      </Modal>

      <Modal isOpen={isMoveModalOpen} onClose={() => setIsMoveModalOpen(false)} title={`Movimentar: ${selectedInstrument?.code}`}>
        <form onSubmit={handleMoveInstrument} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Setor de Destino</label>
            <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={moveData.to_sector} onChange={e => setMoveData({...moveData, to_sector: e.target.value})} required placeholder="Ex: Produção, Qualidade..." />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Responsável</label>
            <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={moveData.responsible} onChange={e => setMoveData({...moveData, responsible: e.target.value})} required placeholder="Nome do colaborador" />
          </div>
          <button type="submit" className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all">Confirmar Movimentação</button>
        </form>
      </Modal>

      <Modal isOpen={isCalibrateModalOpen} onClose={() => setIsCalibrateModalOpen(false)} title={`Nova Calibração: ${selectedInstrument?.code}`}>
        <form onSubmit={handleCalibrateInstrument} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Data</label>
              <input type="date" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={calibrateData.date} onChange={e => setCalibrateData({...calibrateData, date: e.target.value})} required />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Resultado</label>
              <select className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={calibrateData.result} onChange={e => setCalibrateData({...calibrateData, result: e.target.value})}>
                <option value="APROVADO">APROVADO</option>
                <option value="REPROVADO">REPROVADO</option>
                <option value="APROVADO C/ RESTRIÇÃO">APROVADO C/ RESTRIÇÃO</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Responsável</label>
            <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={calibrateData.responsible} onChange={e => setCalibrateData({...calibrateData, responsible: e.target.value})} required />
          </div>
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Observações</label>
            <textarea className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={calibrateData.notes} onChange={e => setCalibrateData({...calibrateData, notes: e.target.value})} rows={3} />
          </div>
          <button type="submit" className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all">Registrar Calibração</button>
        </form>
      </Modal>

      <Modal isOpen={isHistoryModalOpen} onClose={() => setIsHistoryModalOpen(false)} title={`Histórico: ${selectedInstrument?.code}`}>
        <div className="flex justify-end mb-4 no-print">
          <button 
            onClick={() => window.print()}
            className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            <FileText size={14} />
            Imprimir PDF
          </button>
        </div>
        <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-2">
          <div>
            <h4 className="text-xs font-bold uppercase text-slate-400 mb-3 flex items-center gap-2">
              <History size={14} /> Calibrações
            </h4>
            <div className="space-y-3">
              {historyData.calibrations.length === 0 ? <p className="text-sm text-slate-500 italic">Nenhum registro encontrado.</p> : 
                historyData.calibrations.map((c: any) => (
                  <div key={c.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-sm font-bold">{new Date(c.date).toLocaleDateString('pt-BR')}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${c.result === 'APROVADO' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'}`}>{c.result}</span>
                    </div>
                    <p className="text-xs text-slate-500">Resp: {c.responsible}</p>
                    {c.notes && <p className="text-xs mt-1 text-slate-600 dark:text-slate-400 italic">"{c.notes}"</p>}
                  </div>
                ))
              }
            </div>
          </div>
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase text-slate-400 mb-3 flex items-center gap-2">
              <ArrowRightLeft size={14} /> Movimentações
            </h4>
            <div className="space-y-3">
              {historyData.movements.length === 0 ? <p className="text-sm text-slate-500 italic">Nenhum registro encontrado.</p> : 
                historyData.movements.map((m: any) => (
                  <div key={m.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                    <div className="flex items-center gap-2 text-sm mb-1">
                      <span className="font-medium">{m.from_sector}</span>
                      <ChevronRight size={14} className="text-slate-400" />
                      <span className="font-bold text-blue-600">{m.to_sector}</span>
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-500 uppercase font-bold">
                      <span>{new Date(m.date).toLocaleString('pt-BR')}</span>
                      <span>Resp: {m.responsible}</span>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        </div>
      </Modal>

      <Modal isOpen={isGlobalMoveModalOpen} onClose={() => setIsGlobalMoveModalOpen(false)} title="Movimentar Instrumento">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Selecione o Instrumento</label>
            <select 
              className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600"
              onChange={(e) => {
                const inst = instruments.find(i => i.id === parseInt(e.target.value));
                if (inst) setSelectedInstrument(inst);
              }}
            >
              <option value="">Selecione...</option>
              {instruments.map(i => (
                <option key={i.id} value={i.id}>{i.code} - {i.description}</option>
              ))}
            </select>
          </div>
          {selectedInstrument && (
            <form onSubmit={handleMoveInstrument} className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <p className="text-sm text-slate-500">Setor atual: <span className="font-bold">{selectedInstrument.current_sector}</span></p>
              <div>
                <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Setor de Destino</label>
                <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={moveData.to_sector} onChange={e => setMoveData({...moveData, to_sector: e.target.value})} required placeholder="Ex: Produção, Qualidade..." />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Responsável</label>
                <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 outline-none focus:ring-2 focus:ring-blue-600" value={moveData.responsible} onChange={e => setMoveData({...moveData, responsible: e.target.value})} required placeholder="Nome do colaborador" />
              </div>
              <button type="submit" className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all">Confirmar Movimentação</button>
            </form>
          )}
        </div>
      </Modal>
    </div>
  );
}
